package com.hayroyalconsult.maverickstl.mychat.utility

import android.content.Context

/**
 * Created by robot on 5/10/18.
 */
class Utils(var context : Context){


}